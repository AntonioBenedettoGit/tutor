# English Tutor Bot — tutor di grammatica inglese su Telegram, senza AI

Bot Telegram che fa da tutor di grammatica inglese per una scuola di inglese,
usando come unica fonte il libro **«English Grammar: A Complete Guide (A1-C1)»**.

- **Zero AI, zero API key di intelligenza artificiale, zero costi ricorrenti.**
  Tutte le domande, le spiegazioni e le risposte sono estratte dal libro
  (25 capitoli, ~1.600 esempi corretti/errati, 269 esercizi con soluzioni,
  146 verbi irregolari, 91 voci di glossario) e salvate in `data/kb.json`.
- **Interfaccia bilingue IT/EN**, scelta dall'utente al primo avvio (`/lang` per cambiarla).
- **Nessun dato dello studente esce dal server**: niente servizi esterni, niente cloud AI.
- Comportamento deterministico e verificabile: la scuola sa esattamente cosa può dire il bot.

---

## Cosa può fare

| Modalità | Comando | Descrizione |
|---|---|---|
| Quiz grammaticale | `/quiz` | 10 domande a risposta rapida: «corretta o errata?» sugli esempi del libro, «quale frase è corretta?» sulle coppie errore→correzione, e scelte multiple sugli esercizi con opzioni. Con punteggio e riferimento al capitolo |
| Quiz su un capitolo | pulsante «Quiz su questo capitolo» dopo una spiegazione | Stesso quiz ma limitato a un capitolo |
| Esercizi del libro | `/esercizi` | I 25 capitoli di «Practice» del libro, uno alla volta, con «mostra la risposta» (la soluzione ufficiale del libro) o «salta». Puoi anche scrivere la tua risposta in chat e confrontarla |
| Spiegazioni | `/spiega <argomento>` oppure scrivi liberamente | Cerca l'argomento nel libro (in italiano o inglese: «passivo», «present perfect», «question tags»…) e riassume il capitolo: regole, errori comuni ed esempi ✓/✗, con paginazione |
| Indice capitoli | `/capitoli` | Leggere un capitolo completo del libro, pagina per pagina |
| Verbi irregolari | `/verbi` + verbo | Tre forme del verbo dal libro (`go → went → gone`); riconosce anche le forme flesse (`went`) e dice se il verbo è regolare |
| Glossario | `/glossario` + termine | Definizioni del glossario del libro («gerund», «article», «clause»…) |

## Installazione (5 minuti)

1. **Crea il bot su Telegram**: apri [@BotFather](https://t.me/BotFather) → `/newbot`
   → scegli nome e username → BotFather ti dà un **token** (`123456:ABC-DEF...`).
2. **Configura il token**:
   ```bash
   cp .env.example .env
   # apri .env e incolla il token dopo BOT_TOKEN=
   ```
3. **Installa le dipendenze** (Python 3.10+):
   ```bash
   python3 -m venv venv && source venv/bin/activate   # facoltativo ma consigliato
   pip install -r requirements.txt
   ```
4. **Avvia**:
   ```bash
   python3 bot.py
   ```
   Apri il bot su Telegram e invia `/start`. Fermare con Ctrl-C.

Il bot usa il *long polling*: si connette in uscita ai server Telegram,
quindi funziona anche dietro router/NAT senza aprire porte né configurare certificati.

---

## «Cosa devo hostare?» — come funziona davvero

Distinguere i tre pezzi evita confusioni:

1. **Telegram NON ospita il tuo bot.** Telegram è solo il "postino": riceve i
   messaggi degli studenti e li consegna al tuo programma, che risponde.
2. **Cosa gira da te**: `bot.py` + `data/kb.json`. Il "database" è semplicemente
   un file JSON (592 KB) che viaggia insieme al codice: **non c'è un database
   server da installare** (niente MySQL, niente Redis). Lo stato delle sessioni
   vive in memoria: se riavvii il bot, gli studenti riprendono dal menu.
3. **GitHub ospita il codice, non l'esecuzione.** Su GitHub metti il progetto per
   versionarlo e condividerlo; il processo attivo va invece avviato da qualche parte.

Quindi per far funzionare il bot servono due cose distinte:
- **codice su GitHub** (una volta, vedi sotto);
- **un posto dove eseguirlo** (continuamente). Opzioni:

| Opzione | Costo | Adatta a |
|---|---|---|
| Il tuo PC / Mac (avvii `python3 bot.py`) | 0 | Prove e demo: funziona finché il computer è acceso |
| Raspberry Pi o vecchio PC in sede | 0 | Scuola con una postazione fissa: la soluzione più semplice e privata |
| VPS economico (es. 4-6 €/mese) o Oracle Cloud Always Free | ~0 | Funzionamento 24/7 affidabile |
| Piattaforme tipo Railway/Render | ~0 con limiti | Possibili ma meno semplici per un processo long-running |

**Esempio: farlo girare 24/7 su un server Linux con systemd**

```bash
# sul server: clona il repo, crea il .env, installa le dipendenze, poi:
sudo tee /etc/systemd/system/englishtutor.service > /dev/null <<'EOF'
[Unit]
Description=English Tutor Telegram Bot
After=network-online.target

[Service]
User=tuo Utente
WorkingDirectory=/percorso/english-tutor-bot
ExecStart=/percorso/english-tutor-bot/venv/bin/python bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now englishtutor
sudo systemctl status englishtutor   # deve risultare active (running)
```

---

## Pubblicare il progetto su GitHub

```bash
cd english-tutor-bot
git init
git add .
git commit -m "Tutor di inglese su Telegram basato sul libro (no AI)"
# crea il repository vuoto su github.com (es. english-tutor-bot) poi:
git remote add origin git@github.com:UTENTE/english-tutor-bot.git
git branch -M main
git push -u origin main
```

Il file `.gitignore` esclude `.env`: **il token del bot non verrà mai pubblicato**.
Se per errore lo hai committato, revocalo subito da @BotFather (`/revoke`).
`data/kb.json` DEVE restare nel repository: chi clona il progetto ha già
tutti i contenuti e non ha bisogno del PDF del libro.

## Rigenerare la knowledge base dal PDF (facoltativo)

`data/kb.json` è già incluso e pronto. Rigeneralo solo se aggiorni il libro:

```bash
pip install pypdf            # oppure installa poppler-utils (comando pdftotext)
python3 build_kb.py "percorso/libro.pdf" data/kb.json
```

Lo script stampa una diagnostica per capitolo (esempi, coppie di correzione,
esercizi abbinati alle soluzioni). Con pdftotext installato i verbi irregolari
vengono letti dalla tabella con le colonne preservate; senza, usa il fallback.

## Personalizzazione rapida

- **Quante domande per quiz**: `QUIZ_SIZE` in `bot.py`.
- **Argomenti riconosciuti** (ricerca spiegazioni): dizionario `SYNONYMS` in
  `build_kb.py` — aggiungi righe tipo `"futuro": [11]` e rigenera la KB.
- **Testi dell'interfaccia** (IT/EN): `tutor/texts.py`.
- **Filtri qualità** (lunghezza esempi, note scartate): funzioni `extract_*` in `build_kb.py`.

## Struttura del progetto

```
english-tutor-bot/
├── bot.py              # il bot Telegram (python-telegram-bot, polling)
├── build_kb.py         # parser: PDF del libro -> data/kb.json (una tantum)
├── data/kb.json        # knowledge base pronta (capitoli, esempi, esercizi…)
├── tutor/
│   ├── kb.py           # ricerca argomenti, verbi, glossario, paginazione
│   └── texts.py        # interfaccia bilingue IT/EN
├── requirements.txt
├── .env.example        # modello per il token del bot
└── .gitignore
```

## Limiti noti (versione 1, senza AI — scelti di proposito)

- I contenuti sono quelli del libro: le domande di quiz ripetono gli esempi
  del libro (sono oltre 1.500, quindi la ripetizione emerge solo dopo molto uso).
- Le spiegazioni riportano il testo del libro, non lo riformulano.
- **Non c'è la correzione di frasi libere**: l'utente può esercitarsi con gli
  esercizi del libro e confrontare le risposte, ma il bot non analizza frasi
  scritte a caso. È l'evoluzione naturale della versione 2 (aggiungere un'AI
  gratuita SOLO per questa funzione, lasciando il resto offline).
- Le sessioni (quiz in corso, punteggi parziali) vivono in memoria: un riavvio
  le azzera, senza danni.

## Note per la scuola

I contenuti sono tratti dal libro della scuola: usa il bot per uso didattico
interno. La versione senza AI non invia nulla a servizi terzi: le chat restano
tra Telegram e il tuo server.
